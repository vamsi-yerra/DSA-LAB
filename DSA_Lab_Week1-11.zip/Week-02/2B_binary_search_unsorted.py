# Week 2 - B(ii): Binary search on an unsorted list (sorted first)
def binary_search(arr, key):
    arr.sort()
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == key:
            return mid
        elif arr[mid] < key:
            low = mid + 1
        else:
            high = mid - 1
    return -1

n = int(input("Enter number of elements: "))
arr = []
print("Enter elements:")
for i in range(n):
    arr.append(int(input()))

key = int(input("Enter the element to search: "))
result = binary_search(arr, key)
if result != -1:
    print("Element found at index", result)
else:
    print("Element not found")
