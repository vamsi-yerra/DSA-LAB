# Data Structures and Algorithms Lab (23CSE203)

Python programs for Weeks 1-11 of the DSA lab manual.

| Week | Topic | Programs |
|------|-------|----------|
| Week-01 | Recursion | 1A countdown, 1B power, 1C employee search, 1D factorial, 1E Fibonacci |
| Week-02 | Searching | 2A linear search, 2B binary search (sorted / unsorted) |
| Week-03 | Elementary sorting | 3A bubble, 3B insertion, 3C selection |
| Week-04 | Advanced sorting | 4A merge sort, 4B quick sort |
| Week-05 | Linked lists | 5A singly, 5B doubly, 5C circular |
| Week-06 | Stacks | 6A array-based, 6B linked-list-based |
| Week-07 | Queues | 7A array, 7B linked list, 7C circular array, 7D circular linked list |
| Week-08 | Binary trees | 8A array-based, 8B linked-list-based |
| Week-09 | Binary search tree | 9 BST with insert, delete, traversals, counts, height |
| Week-10 | AVL tree | 10 AVL tree with rotations, insert, delete, traversals |
| Week-11 | Hashing | 11 separate chaining, linear probing, quadratic probing |

Run any program with `python3 <file>.py`. Most are menu-driven and read input from the console.
