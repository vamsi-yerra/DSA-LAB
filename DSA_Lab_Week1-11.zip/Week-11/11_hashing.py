# Week 11 - Hashing: Separate chaining, Linear probing and Quadratic probing
size = 10

# Separate chaining
def separate_chaining(keys):
    table = [[] for i in range(size)]
    for key in keys:
        index = key % size
        table[index].append(key)
    print("\n Separate Chaining:")
    for i in range(size):
        print(i, ":", table[i])

# Linear probing
def linear_probing(keys):
    table = [None] * size
    for key in keys:
        index = key % size
        while table[index] is not None:
            index = (index + 1) % size
        table[index] = key
    print("\nLinear Probing:")
    for i in range(size):
        print(i, ":", table[i])

# Quadratic probing
def quadratic_probing(keys):
    table = [None] * size
    for key in keys:
        index = key % size
        i = 0
        while i < size:
            new_index = (index + i * i) % size
            if table[new_index] is None:
                table[new_index] = key
                break
            i += 1
    print("\n Quadratic Probing:")
    for i in range(size):
        print(i, ":", table[i])

# Main program
keys = list(map(int, input("Enter the keys: ").split()))

separate_chaining(keys)
linear_probing(keys)
quadratic_probing(keys)
